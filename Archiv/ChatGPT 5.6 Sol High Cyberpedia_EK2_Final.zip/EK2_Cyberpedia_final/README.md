# Cyberpedia – EK2 Digitalprojekt

Finale, redaktionell konsolidierte Fassung des Homepageprojekts der Eingangsklasse EK2.

## Projektstruktur

- `index.html` – Startseite, Themenübersicht und Glossar
- `netzwerke.html` – WLAN, Funktechnik, Router, Kupfer und Glasfaser inklusive Simulationen
- `sicherheit.html` – Cybersicherheit, Kontenschutz, Backups und Datenschutz
- `medienkompetenz.html` – Internet, Suchmaschinen, Quellenprüfung, Fake News und vernetzte Gesellschaft
- `quiz.html` – zufallsgenerierter Lerncheck
- `style.css` – einzige zentrale CSS-Datei
- `script.js` – Navigation, Darstellungsmodus, Simulationen, Glossarsuche und Quiz
- `assets/` – Logo und Projektgrafik

## Nutzung

Die Homepage benötigt keinen Build-Prozess. `index.html` kann lokal geöffnet oder der gesamte Ordner auf einen statischen Webserver beziehungsweise Replit hochgeladen werden.

Für alle Funktionen sollte die Ordnerstruktur unverändert bleiben. Externe Links werden ausschließlich für weiterführende Quellen geöffnet; die eigentliche Homepage funktioniert offline.

## Redaktionelle Hinweise

- Mehrere einzelne Schülerseiten wurden in wenige, klar gegliederte Kapitel zusammengeführt.
- Technische Aussagen wurden sprachlich und fachlich präzisiert.
- Platzhalter, doppelte Seiten, Inline-CSS und isolierte Einzelskripte wurden entfernt.
- Das Layout ist responsiv, tastaturbedienbar und unterstützt einen hellen sowie dunklen Darstellungsmodus.
- Die Simulationen sind didaktische Modelle und keine Mess- oder Planungstools.

© 2026 Cyberpedia · Eingangsklasse EK2
